//
//  AppDelegate.swift
//  Assignment 1
//
//  Created by Angela Baruth on 01/01/17.
//  Copyright © 2017 Spring 2017. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

